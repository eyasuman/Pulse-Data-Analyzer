import { db } from "@workspace/db";
import {
  providersTable, appointmentsTable, revenueTable,
  institutesTable, bannersTable, reviewsTable,
  patientsTable, auditLogsTable, teleradiologyTable,
  platformSettingsTable,
} from "@workspace/db";

async function seed() {
  console.log("Seeding database...");

  // Providers
  await db.delete(providersTable);
  await db.insert(providersTable).values([
    { id: "doc_001", name: "Dr. Amina Khalid", specialty: "Cardiology", category: "doctor", status: "Active", email: "amina.khalid@pulse.io", phone: "+971 50 123 4567", city: "Dubai", consultationFee: "350", experienceYears: 14, licenseNo: "DXB-MED-1234", bio: "Experienced cardiologist specializing in interventional procedures and preventive cardiology.", serviceModes: { video: true, audio: true, inPerson: true, homeVisit: false } },
    { id: "doc_002", name: "Dr. Faisal Al-Rashid", specialty: "Neurology", category: "doctor", status: "Active", email: "faisal.rashid@pulse.io", phone: "+971 55 234 5678", city: "Abu Dhabi", consultationFee: "400", experienceYears: 18, licenseNo: "AUH-MED-5678", bio: "Leading neurologist with expertise in stroke management and epilepsy treatment.", serviceModes: { video: true, audio: false, inPerson: true, homeVisit: false } },
    { id: "doc_003", name: "Dr. Sara Mohammed", specialty: "Pediatrics", category: "doctor", status: "Pending", email: "sara.mohammed@pulse.io", phone: "+971 52 345 6789", city: "Sharjah", consultationFee: "250", experienceYears: 6, licenseNo: "SHJ-MED-9012", bio: "Dedicated pediatrician with a gentle approach to child healthcare and development.", serviceModes: { video: true, audio: true, inPerson: true, homeVisit: true } },
    { id: "doc_004", name: "Nurse Lina Hassan", specialty: "General Nursing", category: "nurse", status: "Active", email: "lina.hassan@pulse.io", phone: "+971 56 456 7890", city: "Dubai", consultationFee: "150", experienceYears: 9, licenseNo: "DXB-NRS-3456", bio: "Certified nurse specialising in post-operative care and home health services.", serviceModes: { video: false, audio: true, inPerson: true, homeVisit: true } },
    { id: "doc_005", name: "Dr. Omar Al-Zaabi", specialty: "Orthopedics", category: "doctor", status: "Active", email: "omar.zaabi@pulse.io", phone: "+971 58 567 8901", city: "Dubai", consultationFee: "500", experienceYears: 22, licenseNo: "DXB-MED-7890", bio: "Senior orthopedic surgeon with expertise in joint replacement and sports injuries.", serviceModes: { video: true, audio: false, inPerson: true, homeVisit: false } },
    { id: "doc_006", name: "Nutritionist Reem Al-Blooshi", specialty: "Clinical Nutrition", category: "nutritionist", status: "Active", email: "reem.blooshi@pulse.io", phone: "+971 50 678 9012", city: "Abu Dhabi", consultationFee: "200", experienceYears: 7, licenseNo: "AUH-NUT-2345", bio: "Registered dietitian specialising in metabolic disorders and sports nutrition.", serviceModes: { video: true, audio: true, inPerson: true, homeVisit: false } },
    { id: "doc_007", name: "Physio Ahmed Nasser", specialty: "Sports Rehabilitation", category: "physiotherapist", status: "Pending", email: "ahmed.nasser@pulse.io", phone: "+971 52 789 0123", city: "Dubai", consultationFee: "200", experienceYears: 8, licenseNo: "DXB-PHY-6789", bio: "Sports physiotherapist with expertise in injury prevention and performance optimisation.", serviceModes: { video: false, audio: false, inPerson: true, homeVisit: true } },
    { id: "doc_008", name: "Dr. Huda Al-Ali", specialty: "Psychiatry", category: "doctor", status: "Active", email: "huda.alali@pulse.io", phone: "+971 55 890 1234", city: "Abu Dhabi", consultationFee: "450", experienceYears: 11, licenseNo: "AUH-MED-6621", bio: "Psychiatrist with expertise in anxiety disorders, depression, and cognitive behavioural therapy.", serviceModes: { video: true, audio: true, inPerson: true, homeVisit: false } },
  ]);
  console.log("✓ Providers seeded");

  // Appointments
  await db.delete(appointmentsTable);
  await db.insert(appointmentsTable).values([
    { id: "apt_001", doctorName: "Dr. Amina Khalid", patientName: "Khalid Al-Hamdan", specialty: "Cardiology", status: "completed", consultationFee: "350", platformFee: "35", totalPrice: "385", date: new Date("2024-06-10T10:00:00Z"), serviceType: "Video Consultation" },
    { id: "apt_002", doctorName: "Dr. Faisal Al-Rashid", patientName: "Mariam Saeed", specialty: "Neurology", status: "scheduled", consultationFee: "400", platformFee: "40", totalPrice: "440", date: new Date("2024-06-15T14:00:00Z"), serviceType: "In-Person Visit" },
    { id: "apt_003", doctorName: "Dr. Huda Al-Ali", patientName: "Tariq Mansour", specialty: "Psychiatry", status: "completed", consultationFee: "450", platformFee: "45", totalPrice: "495", date: new Date("2024-06-09T09:00:00Z"), serviceType: "Video Consultation" },
    { id: "apt_004", doctorName: "Nurse Lina Hassan", patientName: "Fatima Al-Zahra", specialty: "General Nursing", status: "pending", consultationFee: "150", platformFee: "15", totalPrice: "165", date: new Date("2024-06-16T11:00:00Z"), serviceType: "Home Visit" },
    { id: "apt_005", doctorName: "Physio Ahmed Nasser", patientName: "Yousef Al-Shamsi", specialty: "Sports Rehabilitation", status: "scheduled", consultationFee: "200", platformFee: "20", totalPrice: "220", date: new Date("2024-06-17T08:00:00Z"), serviceType: "In-Person Visit" },
    { id: "apt_006", doctorName: "Dr. Amina Khalid", patientName: "Nour Hassan", specialty: "Cardiology", status: "cancelled", consultationFee: "350", platformFee: "35", totalPrice: "385", date: new Date("2024-06-11T15:00:00Z"), serviceType: "Audio Consultation" },
    { id: "apt_007", doctorName: "Dr. Faisal Al-Rashid", patientName: "Ali Karimi", specialty: "Neurology", status: "completed", consultationFee: "400", platformFee: "40", totalPrice: "440", date: new Date("2024-06-13T10:00:00Z"), serviceType: "Video Consultation" },
    { id: "apt_008", doctorName: "Dr. Huda Al-Ali", patientName: "Omar Rashid", specialty: "Psychiatry", status: "pending", consultationFee: "450", platformFee: "45", totalPrice: "495", date: new Date("2024-06-18T13:00:00Z"), serviceType: "Video Consultation" },
  ]);
  console.log("✓ Appointments seeded");

  // Revenue
  await db.delete(revenueTable);
  await db.insert(revenueTable).values([
    { id: "rev_m_01", month: "Jan", revenue: "12400", appointments: 32 },
    { id: "rev_m_02", month: "Feb", revenue: "15200", appointments: 39 },
    { id: "rev_m_03", month: "Mar", revenue: "18900", appointments: 48 },
    { id: "rev_m_04", month: "Apr", revenue: "16700", appointments: 43 },
    { id: "rev_m_05", month: "May", revenue: "21300", appointments: 55 },
    { id: "rev_m_06", month: "Jun", revenue: "19800", appointments: 51 },
  ]);
  console.log("✓ Revenue seeded");

  // Institutes
  await db.delete(institutesTable);
  await db.insert(institutesTable).values([
    { id: "inst_001", name: "Emirates Medical Center", type: "Hospital", status: "Active", city: "Dubai", address: "Healthcare City, Dubai", phone: "+971 4 362 1111", email: "info@emc.ae", licenseNo: "DXB-HC-0011", totalDoctors: 128, totalBeds: 250, services: ["Cardiology", "Neurology", "Oncology", "Pediatrics", "Surgery"], accreditations: ["JCI", "ISO 9001"] },
    { id: "inst_002", name: "Al Noor Diagnostic Centre", type: "Diagnostic Center", status: "Active", city: "Abu Dhabi", address: "Khalifa Street, Abu Dhabi", phone: "+971 2 678 4444", email: "contact@alnoor.ae", licenseNo: "AUH-DC-0042", totalDoctors: 24, services: ["Radiology", "Pathology", "MRI", "CT Scan", "Blood Tests"] },
    { id: "inst_003", name: "Pulse Wellness Clinic", type: "Clinic", status: "Active", city: "Sharjah", address: "Al Qasba, Sharjah", phone: "+971 6 555 2222", email: "hello@pulseclinic.ae", licenseNo: "SHJ-CL-0088", totalDoctors: 12, services: ["General Practice", "Dermatology", "Physiotherapy"] },
    { id: "inst_004", name: "Medlife Pharmacy Network", type: "Pharmacy", status: "Pending", city: "Dubai", address: "Jumeirah Beach Rd, Dubai", phone: "+971 4 344 9999", email: "ops@medlife.ae", licenseNo: "DXB-PH-0200", totalDoctors: 0, services: ["Prescription Dispensing", "OTC Medicines", "Vitamins & Supplements"] },
    { id: "inst_005", name: "Gulf Rehabilitation Institute", type: "Rehabilitation", status: "Active", city: "Dubai", address: "Al Barsha, Dubai", phone: "+971 4 451 7777", email: "rehab@gulf-rehab.ae", licenseNo: "DXB-RH-0031", totalDoctors: 18, totalBeds: 40, services: ["Physical Therapy", "Occupational Therapy", "Speech Therapy", "Neuro Rehab"], accreditations: ["CARF"] },
    { id: "inst_006", name: "BrightSmile Dental Center", type: "Dental", status: "Suspended", city: "Ajman", address: "Al Rashidiya, Ajman", phone: "+971 6 742 3333", email: "info@brightsmile.ae", licenseNo: "AJM-DN-0014", totalDoctors: 6, services: ["General Dentistry", "Orthodontics", "Implants", "Whitening"] },
  ]);
  console.log("✓ Institutes seeded");

  // Banners
  await db.delete(bannersTable);
  await db.insert(bannersTable).values([
    { id: "ban_001", title: "Summer Health Checkup — 20% Off", message: "Get a comprehensive health screening package this summer. Valid for all registered patients on the Pulse Network platform.", type: "promo", isActive: true, priority: 1, promoCode: "SUMMER20", displayDuration: 8, targetAudience: "Patients", expiresAt: new Date("2024-08-31T23:59:59Z") },
    { id: "ban_002", title: "New Teleradiology Feature Live", message: "Providers can now request teleradiology consultations directly from the platform. Instant access to specialist radiologists 24/7.", type: "info", isActive: true, priority: 2, displayDuration: 6, targetAudience: "Providers" },
    { id: "ban_003", title: "System Maintenance — June 20", message: "Scheduled maintenance window from 2:00 AM to 4:00 AM GST on June 20. Some services may be temporarily unavailable.", type: "alert", isActive: true, priority: 0, displayDuration: 10, targetAudience: "All" },
    { id: "ban_004", title: "Provider Onboarding Bonus", message: "New healthcare providers who complete verification before July 1 receive a 3-month platform fee waiver.", type: "promo", isActive: false, priority: 3, promoCode: "PROVIDER3M", displayDuration: 7, targetAudience: "Providers" },
  ]);
  console.log("✓ Banners seeded");

  // Reviews
  await db.delete(reviewsTable);
  await db.insert(reviewsTable).values([
    { id: "rev_001", doctorId: "doc_001", doctorName: "Dr. Amina Khalid", patientName: "Khalid Al-Hamdan", rating: 5, comment: "Excellent cardiologist. Very thorough in her explanations and genuinely cared about my health. Would highly recommend to anyone.", status: "pinned", createdAt: new Date("2024-06-10T11:00:00Z") },
    { id: "rev_002", doctorId: "doc_002", doctorName: "Dr. Faisal Al-Rashid", patientName: "Mariam Saeed", rating: 4, comment: "Very knowledgeable neurologist. The consultation was a bit rushed but the diagnosis was spot on.", status: "visible", createdAt: new Date("2024-06-09T15:30:00Z") },
    { id: "rev_003", doctorId: "doc_008", doctorName: "Dr. Huda Al-Ali", patientName: "Tariq Mansour", rating: 5, comment: "Life-changing sessions. Dr. Al-Ali is compassionate, professional, and highly skilled. I finally feel understood.", status: "pinned", createdAt: new Date("2024-06-08T09:00:00Z") },
    { id: "rev_004", doctorId: "doc_004", doctorName: "Nurse Lina Hassan", patientName: "Fatima Al-Zahra", rating: 2, comment: "Arrived 45 minutes late for the home visit and didn't bring all the required equipment. Disappointing experience.", status: "visible", createdAt: new Date("2024-06-07T14:00:00Z") },
    { id: "rev_005", doctorId: "doc_001", doctorName: "Dr. Amina Khalid", patientName: "FAKE_ACCOUNT_892", rating: 5, comment: "Best doctor ever!!!! Amazing amazing amazing! Everyone should see her!!", status: "banned", createdAt: new Date("2024-06-06T10:00:00Z") },
    { id: "rev_006", doctorId: "doc_007", doctorName: "Physio Ahmed Nasser", patientName: "Yousef Al-Shamsi", rating: 4, comment: "Ahmed is very skilled in sports rehab. My knee recovery has been much faster than expected.", status: "visible", createdAt: new Date("2024-06-05T16:00:00Z") },
    { id: "rev_007", doctorId: "doc_003", doctorName: "Dr. Sara Mohammed", patientName: "Layla Ibrahim", rating: 1, comment: "DO NOT USE THIS DOCTOR. She is terrible and should not have a license. Complete waste of money!!!!", status: "shadow_banned", createdAt: new Date("2024-06-04T08:00:00Z") },
    { id: "rev_008", doctorId: "doc_005", doctorName: "Dr. Omar Al-Zaabi", patientName: "Ali Karimi", rating: 3, comment: "Competent surgeon but bedside manner could use improvement. The procedure went well though.", status: "visible", createdAt: new Date("2024-06-03T11:00:00Z") },
  ]);
  console.log("✓ Reviews seeded");

  // Patients
  await db.delete(patientsTable);
  await db.insert(patientsTable).values([
    { id: "pat_001", name: "Khalid Al-Hamdan", email: "khalid.hamdan@email.com", phone: "+971 50 111 2233", city: "Dubai", status: "active", totalAppointments: 5, createdAt: new Date("2023-09-01T00:00:00Z") },
    { id: "pat_002", name: "Mariam Saeed", email: "mariam.saeed@email.com", phone: "+971 55 234 5566", city: "Abu Dhabi", status: "active", totalAppointments: 3, createdAt: new Date("2023-11-15T00:00:00Z") },
    { id: "pat_003", name: "Tariq Mansour", email: "tariq.m@email.com", phone: "+971 52 345 6677", city: "Dubai", status: "active", totalAppointments: 8, createdAt: new Date("2023-07-20T00:00:00Z") },
    { id: "pat_004", name: "Fatima Al-Zahra", email: "fatima.alzahra@email.com", city: "Sharjah", status: "active", totalAppointments: 2, createdAt: new Date("2024-01-10T00:00:00Z") },
    { id: "pat_005", name: "Yousef Al-Shamsi", email: "yousef.shamsi@email.com", phone: "+971 56 456 7788", city: "Dubai", status: "active", totalAppointments: 4, createdAt: new Date("2023-12-05T00:00:00Z") },
    { id: "pat_006", name: "Nour Hassan", email: "nour.h@email.com", phone: "+971 54 567 8899", city: "Ajman", status: "suspended", totalAppointments: 1, createdAt: new Date("2024-03-01T00:00:00Z") },
    { id: "pat_007", name: "Ali Karimi", email: "ali.karimi@email.com", phone: "+971 58 678 9900", city: "Abu Dhabi", status: "active", totalAppointments: 6, createdAt: new Date("2023-08-12T00:00:00Z") },
    { id: "pat_008", name: "Layla Ibrahim", email: "layla.ibrahim@email.com", city: "Dubai", status: "active", totalAppointments: 2, createdAt: new Date("2024-02-20T00:00:00Z") },
    { id: "pat_009", name: "Omar Rashid", email: "omar.rashid@email.com", phone: "+971 50 789 0011", city: "Fujairah", status: "active", totalAppointments: 1, createdAt: new Date("2024-04-15T00:00:00Z") },
    { id: "pat_010", name: "Sara Al-Blooshi", email: "sara.blooshi@email.com", phone: "+971 55 890 1122", city: "Dubai", status: "suspended", totalAppointments: 3, createdAt: new Date("2023-10-08T00:00:00Z") },
  ]);
  console.log("✓ Patients seeded");

  // Audit Logs
  await db.delete(auditLogsTable);
  await db.insert(auditLogsTable).values([
    { id: "log_001", actorName: "Admin System", action: "activated provider account for Dr. Amina Khalid", objectType: "provider", type: "Admin", timestamp: new Date("2024-06-14T09:15:00Z") },
    { id: "log_002", actorName: "Khalid Al-Hamdan", action: "booked video consultation with Dr. Amina Khalid", objectType: "appointment", type: "User", timestamp: new Date("2024-06-14T08:45:00Z") },
    { id: "log_003", actorName: "System", action: "platform fee auto-applied to appointment apt_001 (AED 35)", objectType: "payment", type: "System", timestamp: new Date("2024-06-14T08:30:00Z") },
    { id: "log_004", actorName: "Admin System", action: "suspended BrightSmile Dental Center pending license review", objectType: "institute", type: "Admin", timestamp: new Date("2024-06-13T16:00:00Z") },
    { id: "log_005", actorName: "Nour Hassan", action: "cancelled appointment with Dr. Amina Khalid — cancellation fee applied", objectType: "appointment", type: "User", timestamp: new Date("2024-06-13T14:30:00Z") },
    { id: "log_006", actorName: "System", action: "review rev_005 auto-flagged as potential fake account activity", objectType: "review", type: "System", timestamp: new Date("2024-06-13T12:00:00Z") },
    { id: "log_007", actorName: "Admin System", action: "banner ban_001 activated and pushed to all patient devices", objectType: "banner", type: "Admin", timestamp: new Date("2024-06-13T10:00:00Z") },
    { id: "log_008", actorName: "Dr. Faisal Al-Rashid", action: "updated availability schedule for week of June 17", objectType: "provider", type: "User", timestamp: new Date("2024-06-12T17:00:00Z") },
    { id: "log_009", actorName: "System", action: "scheduled maintenance reminder sent to all registered users", objectType: "notification", type: "System", timestamp: new Date("2024-06-12T09:00:00Z") },
    { id: "log_010", actorName: "Admin System", action: "onboarded Emirates Medical Center — 128 doctors imported", objectType: "institute", type: "Admin", timestamp: new Date("2024-06-11T11:30:00Z") },
    { id: "log_011", actorName: "Admin System", action: "Sara Al-Blooshi account suspended due to repeated appointment no-shows", objectType: "patient", type: "Admin", timestamp: new Date("2024-06-10T15:00:00Z") },
    { id: "log_012", actorName: "System", action: "monthly revenue report generated: AED 19,800 for June", objectType: "report", type: "System", timestamp: new Date("2024-06-10T00:01:00Z") },
  ]);
  console.log("✓ Audit logs seeded");

  // Teleradiology Cases
  await db.delete(teleradiologyTable);
  await db.insert(teleradiologyTable).values([
    { id: "trad_001", caseId: "TRAD-2024-0891", patientName: "Khalid Al-Hamdan", radiologistName: "Dr. Reem Al-Mansoori", modality: "MRI", bodyPart: "Brain", status: "urgent", priority: "High", notes: "Patient presenting with sudden onset severe headache. Requires immediate neurological review.", createdAt: new Date("2024-06-14T07:30:00Z") },
    { id: "trad_002", caseId: "TRAD-2024-0890", patientName: "Mariam Saeed", radiologistName: "Dr. Faisal Al-Rashid", modality: "CT Scan", bodyPart: "Chest", status: "in-review", priority: "Normal", notes: "Follow-up scan post-pneumonia treatment at 3-month interval.", createdAt: new Date("2024-06-13T14:00:00Z") },
    { id: "trad_003", caseId: "TRAD-2024-0889", patientName: "Ali Karimi", radiologistName: "Dr. Reem Al-Mansoori", modality: "X-Ray", bodyPart: "Right Knee", status: "completed", notes: "Post-arthroscopy assessment. Results normal. Cleared for physiotherapy.", createdAt: new Date("2024-06-12T10:00:00Z") },
    { id: "trad_004", caseId: "TRAD-2024-0888", patientName: "Layla Ibrahim", modality: "Ultrasound", bodyPart: "Abdomen", status: "pending", priority: "Normal", notes: "Routine obstetric scan at 20 weeks gestation.", createdAt: new Date("2024-06-14T09:00:00Z") },
    { id: "trad_005", caseId: "TRAD-2024-0887", patientName: "Tariq Mansour", radiologistName: "Dr. Faisal Al-Rashid", modality: "PET Scan", bodyPart: "Full Body", status: "in-review", priority: "High", notes: "Oncology staging scan. Prior diagnosis of Stage II lymphoma.", createdAt: new Date("2024-06-13T08:00:00Z") },
    { id: "trad_006", caseId: "TRAD-2024-0886", patientName: "Fatima Al-Zahra", modality: "Mammography", bodyPart: "Bilateral", status: "pending", priority: "Normal", notes: "Annual screening mammogram. No prior history.", createdAt: new Date("2024-06-14T11:00:00Z") },
  ]);
  console.log("✓ Teleradiology cases seeded");

  // Platform Settings (singleton)
  await db.delete(platformSettingsTable);
  await db.insert(platformSettingsTable).values({
    id: "singleton",
    platformFee: "10",
    cancellationNoticePeriodHours: 24,
    cancellationPenaltyFee: "50",
    reminderCadence: "daily",
    gatewayPassword: "0000",
  });
  console.log("✓ Platform settings seeded");

  console.log("\nAll data seeded successfully!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
