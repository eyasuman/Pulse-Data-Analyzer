# Pulse Network Admin Console

A full-stack healthcare administration mobile app (Expo SDK 54) for managing providers, appointments, revenue, institutes, banners, reviews, patients, teleradiology cases, and platform settings — all backed by a live PostgreSQL database.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, proxied to /api)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/scripts run seed` — reseed the database with sample data
- Required env: `DATABASE_URL` — Postgres connection string (managed by Replit)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Mobile: Expo SDK 54 (expo-router v6), React Native 0.81.5, dark-themed
- API: Express 5 (port 8080, proxied at `/api`)
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- Build: esbuild (CJS bundle)

## Where things live

- `lib/db/src/schema/` — 10 Drizzle schema files (providers, appointments, revenue, institutes, banners, reviews, patients, audit_logs, teleradiology, settings)
- `artifacts/api-server/src/routes/` — Express routes for each entity (10 route files)
- `artifacts/mobile/context/DataContext.tsx` — React context that fetches all data from the API; source of truth for all UI state
- `artifacts/mobile/app/` — Expo Router screens (dashboard, providers, appointments, revenue, institutes, banners, reviews, patients, teleradiology, settings, audit)
- `scripts/src/seed.ts` — Seed script for all 10 tables

## Architecture decisions

- **API URL derivation**: The Expo web app replaces `.expo.janeway.replit.dev` → `.janeway.replit.dev` in `window.location.hostname` to reach the main proxy at `/api`. No hardcoded URLs.
- **Dark theme only**: `hooks/useColors.ts` always returns `colors.dark` — no light mode toggle.
- **No AsyncStorage**: DataContext fetches from the API on mount; no local persistence layer. All writes go to the DB immediately via PATCH/POST/DELETE.
- **Singleton settings row**: `platform_settings` table has a single row with `id = "singleton"`.
- **No fontFamily in StyleSheets**: System font fallback used everywhere to prevent invisible text on Expo web.

## Product

Pulse Network Admin Console lets healthcare platform admins:
- Manage & approve provider (doctor/nurse/physio/nutritionist) accounts
- View all appointments with financial breakdowns
- Track platform revenue by month
- Onboard and manage healthcare institutes
- Publish promotional banners with targeting and expiry
- Moderate patient reviews (pin, ban, shadow-ban)
- View and suspend patient accounts
- Triage teleradiology imaging cases
- Review a full audit log of all platform activity
- Configure platform-wide fee settings

## User preferences

- All data must come from the database — no hardcoded mock data anywhere
- Dark theme always forced on

## Gotchas

- Run `pnpm --filter @workspace/db run push` after any schema change before restarting the API server
- Run `pnpm --filter @workspace/scripts run seed` to restore sample data after wiping tables
- Expo app is on `expo.janeway.replit.dev` domain (bypasses shared proxy); API calls use hostname transformation to reach `/api`
- `pnpm run typecheck:libs` must succeed before artifact typechecks (builds composite libs first)

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
