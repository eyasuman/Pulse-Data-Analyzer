-- Run this entire file in: Supabase Dashboard → SQL Editor → New Query → Paste → Run

-- 1. PATIENTS
create table if not exists public.patients (
  id text primary key default gen_random_uuid()::text,
  name text not null,
  email text not null,
  phone text,
  city text,
  status text not null default 'active',
  "totalAppointments" integer not null default 0,
  "createdAt" timestamptz not null default now()
);
alter table public.patients enable row level security;
create policy "service role full access" on public.patients using (true) with check (true);

-- 2. INSTITUTES
create table if not exists public.institutes (
  id text primary key default gen_random_uuid()::text,
  name text not null,
  type text not null,
  status text not null default 'Pending',
  city text not null,
  address text not null default '',
  phone text not null default '',
  email text not null default '',
  "licenseNo" text not null default '',
  "totalDoctors" integer not null default 0,
  "totalBeds" integer,
  services text[] not null default '{}',
  accreditations text[],
  "createdAt" timestamptz not null default now()
);
alter table public.institutes enable row level security;
create policy "service role full access" on public.institutes using (true) with check (true);

-- 3. REVENUE
create table if not exists public.revenue (
  id text primary key,
  month text not null,
  revenue numeric(12,2) not null,
  appointments integer not null default 0
);
alter table public.revenue enable row level security;
create policy "service role full access" on public.revenue using (true) with check (true);

-- 4. TELERADIOLOGY CASES
create table if not exists public."teleradiologyCases" (
  id text primary key default gen_random_uuid()::text,
  "caseId" text not null unique,
  "patientName" text not null,
  "radiologistName" text,
  modality text not null,
  "bodyPart" text not null,
  status text not null default 'pending',
  priority text,
  notes text,
  "createdAt" timestamptz not null default now()
);
alter table public."teleradiologyCases" enable row level security;
create policy "service role full access" on public."teleradiologyCases" using (true) with check (true);

-- 5. Add missing columns to settings table (if not already present)
alter table public.settings add column if not exists "gatewayPassword" text not null default '0000';
alter table public.settings add column if not exists "inactivityTimeoutMinutes" integer not null default 5;

-- Ensure singleton settings row exists
insert into public.settings (id, "fixedPlatformFee", "reminderCadence", "gatewayPassword", "inactivityTimeoutMinutes", "updatedBy")
values ('singleton', 10, 'daily', '0000', 5, 'system')
on conflict (id) do nothing;

-- 6. SEED PATIENTS
insert into public.patients (id, name, email, phone, city, status, "totalAppointments", "createdAt") values
('pat_001','Khalid Al-Hamdan','khalid.hamdan@email.com','+971 50 111 2233','Dubai','active',5,'2023-09-01T00:00:00Z'),
('pat_002','Mariam Saeed','mariam.saeed@email.com','+971 55 234 5566','Abu Dhabi','active',3,'2023-11-15T00:00:00Z'),
('pat_003','Tariq Mansour','tariq.m@email.com','+971 52 345 6677','Dubai','active',8,'2023-07-20T00:00:00Z'),
('pat_004','Fatima Al-Zahra','fatima.alzahra@email.com',null,'Sharjah','active',2,'2024-01-10T00:00:00Z'),
('pat_005','Yousef Al-Shamsi','yousef.shamsi@email.com','+971 56 456 7788','Dubai','active',4,'2023-12-05T00:00:00Z'),
('pat_006','Nour Hassan','nour.h@email.com','+971 54 567 8899','Ajman','suspended',1,'2024-03-01T00:00:00Z'),
('pat_007','Ali Karimi','ali.karimi@email.com','+971 58 678 9900','Abu Dhabi','active',6,'2023-08-12T00:00:00Z'),
('pat_008','Layla Ibrahim','layla.ibrahim@email.com',null,'Dubai','active',2,'2024-02-20T00:00:00Z'),
('pat_009','Omar Rashid','omar.rashid@email.com','+971 50 789 0011','Fujairah','active',1,'2024-04-15T00:00:00Z'),
('pat_010','Sara Al-Blooshi','sara.blooshi@email.com','+971 55 890 1122','Dubai','suspended',3,'2023-10-08T00:00:00Z')
on conflict (id) do nothing;

-- 7. SEED INSTITUTES
insert into public.institutes (id,name,type,status,city,address,phone,email,"licenseNo","totalDoctors","totalBeds",services,accreditations,"createdAt") values
('inst_001','Emirates Medical Center','Hospital','Active','Dubai','Healthcare City, Dubai','+971 4 362 1111','info@emc.ae','DXB-HC-0011',128,250,array['Cardiology','Neurology','Oncology','Pediatrics','Surgery'],array['JCI','ISO 9001'],'2024-01-01T00:00:00Z'),
('inst_002','Al Noor Diagnostic Centre','Diagnostic Center','Active','Abu Dhabi','Khalifa Street, Abu Dhabi','+971 2 678 4444','contact@alnoor.ae','AUH-DC-0042',24,null,array['Radiology','Pathology','MRI','CT Scan','Blood Tests'],null,'2024-01-02T00:00:00Z'),
('inst_003','Pulse Wellness Clinic','Clinic','Active','Sharjah','Al Qasba, Sharjah','+971 6 555 2222','hello@pulseclinic.ae','SHJ-CL-0088',12,null,array['General Practice','Dermatology','Physiotherapy'],null,'2024-01-03T00:00:00Z'),
('inst_004','Medlife Pharmacy Network','Pharmacy','Pending','Dubai','Jumeirah Beach Rd, Dubai','+971 4 344 9999','ops@medlife.ae','DXB-PH-0200',0,null,array['Prescription Dispensing','OTC Medicines','Vitamins & Supplements'],null,'2024-01-04T00:00:00Z'),
('inst_005','Gulf Rehabilitation Institute','Rehabilitation','Active','Dubai','Al Barsha, Dubai','+971 4 451 7777','rehab@gulf-rehab.ae','DXB-RH-0031',18,40,array['Physical Therapy','Occupational Therapy','Speech Therapy','Neuro Rehab'],array['CARF'],'2024-01-05T00:00:00Z'),
('inst_006','BrightSmile Dental Center','Dental','Suspended','Ajman','Al Rashidiya, Ajman','+971 6 742 3333','info@brightsmile.ae','AJM-DN-0014',6,null,array['General Dentistry','Orthodontics','Implants','Whitening'],null,'2024-01-06T00:00:00Z')
on conflict (id) do nothing;

-- 8. SEED REVENUE
insert into public.revenue (id,month,revenue,appointments) values
('rev_m_01','Jan',12400,32),
('rev_m_02','Feb',15200,39),
('rev_m_03','Mar',18900,48),
('rev_m_04','Apr',16700,43),
('rev_m_05','May',21300,55),
('rev_m_06','Jun',19800,51)
on conflict (id) do nothing;

-- 9. SEED TELERADIOLOGY CASES
insert into public."teleradiologyCases" (id,"caseId","patientName","radiologistName",modality,"bodyPart",status,priority,notes,"createdAt") values
('trad_001','TRAD-2024-0891','Khalid Al-Hamdan','Dr. Reem Al-Mansoori','MRI','Brain','urgent','High','Patient presenting with sudden onset severe headache. Requires immediate neurological review.','2024-06-14T07:30:00Z'),
('trad_002','TRAD-2024-0890','Mariam Saeed','Dr. Faisal Al-Rashid','CT Scan','Chest','in-review','Normal','Follow-up scan post-pneumonia treatment at 3-month interval.','2024-06-13T14:00:00Z'),
('trad_003','TRAD-2024-0889','Ali Karimi','Dr. Reem Al-Mansoori','X-Ray','Right Knee','completed',null,'Post-arthroscopy assessment. Results normal. Cleared for physiotherapy.','2024-06-12T10:00:00Z'),
('trad_004','TRAD-2024-0888','Layla Ibrahim',null,'Ultrasound','Abdomen','pending','Normal','Routine obstetric scan at 20 weeks gestation.','2024-06-14T09:00:00Z'),
('trad_005','TRAD-2024-0887','Tariq Mansour','Dr. Faisal Al-Rashid','PET Scan','Full Body','in-review','High','Oncology staging scan. Prior diagnosis of Stage II lymphoma.','2024-06-13T08:00:00Z'),
('trad_006','TRAD-2024-0886','Fatima Al-Zahra',null,'Mammography','Bilateral','pending','Normal','Annual screening mammogram. No prior history.','2024-06-14T11:00:00Z')
on conflict (id) do nothing;
