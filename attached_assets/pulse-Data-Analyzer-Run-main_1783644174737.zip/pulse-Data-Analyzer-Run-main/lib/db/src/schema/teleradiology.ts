import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const teleradiologyTable = pgTable("teleradiology_cases", {
  id: text("id").primaryKey(),
  caseId: text("case_id").notNull().unique(),
  patientName: text("patient_name").notNull(),
  radiologistName: text("radiologist_name"),
  modality: text("modality").notNull(),
  bodyPart: text("body_part").notNull(),
  status: text("status").notNull().default("pending"),
  priority: text("priority"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTeleradiologySchema = createInsertSchema(teleradiologyTable).omit({ createdAt: true });
export type InsertTeleradiology = z.infer<typeof insertTeleradiologySchema>;
export type TeleradiologyCase = typeof teleradiologyTable.$inferSelect;
