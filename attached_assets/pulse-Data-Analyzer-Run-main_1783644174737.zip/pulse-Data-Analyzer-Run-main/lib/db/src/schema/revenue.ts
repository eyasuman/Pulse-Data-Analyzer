import { pgTable, text, integer, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const revenueTable = pgTable("revenue", {
  id: text("id").primaryKey(),
  month: text("month").notNull(),
  revenue: numeric("revenue", { precision: 12, scale: 2 }).notNull(),
  appointments: integer("appointments").notNull().default(0),
});

export const insertRevenueSchema = createInsertSchema(revenueTable);
export type InsertRevenue = z.infer<typeof insertRevenueSchema>;
export type Revenue = typeof revenueTable.$inferSelect;
