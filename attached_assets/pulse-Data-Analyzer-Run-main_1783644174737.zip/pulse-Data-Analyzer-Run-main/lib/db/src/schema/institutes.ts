import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const institutesTable = pgTable("institutes", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  status: text("status").notNull().default("Pending"),
  city: text("city").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  licenseNo: text("license_no").notNull(),
  totalDoctors: integer("total_doctors").notNull().default(0),
  totalBeds: integer("total_beds"),
  services: text("services").array().notNull().default([]),
  accreditations: text("accreditations").array(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertInstituteSchema = createInsertSchema(institutesTable).omit({ createdAt: true });
export type InsertInstitute = z.infer<typeof insertInstituteSchema>;
export type Institute = typeof institutesTable.$inferSelect;
