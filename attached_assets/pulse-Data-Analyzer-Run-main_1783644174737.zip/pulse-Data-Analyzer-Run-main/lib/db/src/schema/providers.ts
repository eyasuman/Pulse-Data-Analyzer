import { pgTable, text, integer, numeric, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const providersTable = pgTable("providers", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  specialty: text("specialty").notNull(),
  category: text("category").notNull(),
  status: text("status").notNull().default("Pending"),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  city: text("city").notNull(),
  consultationFee: numeric("consultation_fee", { precision: 10, scale: 2 }).notNull(),
  experienceYears: integer("experience_years").notNull().default(0),
  licenseNo: text("license_no").notNull(),
  bio: text("bio").notNull().default(""),
  serviceModes: jsonb("service_modes").notNull().default({ video: false, audio: false, inPerson: true, homeVisit: false }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertProviderSchema = createInsertSchema(providersTable).omit({ createdAt: true });
export type InsertProvider = z.infer<typeof insertProviderSchema>;
export type Provider = typeof providersTable.$inferSelect;
