import { pgTable, text, integer, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const platformSettingsTable = pgTable("platform_settings", {
  id: text("id").primaryKey().default("singleton"),
  platformFee: numeric("platform_fee", { precision: 5, scale: 2 }).notNull().default("10"),
  cancellationNoticePeriodHours: integer("cancellation_notice_period_hours").notNull().default(24),
  cancellationPenaltyFee: numeric("cancellation_penalty_fee", { precision: 10, scale: 2 }).notNull().default("50"),
  reminderCadence: text("reminder_cadence").notNull().default("daily"),
  gatewayPassword: text("gateway_password").notNull().default("0000"),
  inactivityTimeoutMinutes: integer("inactivity_timeout_minutes").notNull().default(5),
});

export const insertPlatformSettingsSchema = createInsertSchema(platformSettingsTable);
export type InsertPlatformSettings = z.infer<typeof insertPlatformSettingsSchema>;
export type PlatformSettings = typeof platformSettingsTable.$inferSelect;
