const SUPABASE_URL = "https://qxdqubzymuqgppwlzbsc.supabase.co";

export async function writeAudit(
  action: string,
  objectType: string,
  actorName = "Admin System",
  type: "Admin" | "System" | "User" = "Admin",
): Promise<void> {
  const key = process.env.SUPABASE_SERVICE_KEY;
  if (!key) return;
  try {
    await fetch(`${SUPABASE_URL}/rest/v1/auditLogs`, {
      method: "POST",
      headers: {
        "apikey": key,
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json",
        "Prefer": "return=minimal",
      },
      body: JSON.stringify({
        actorName,
        action,
        objectType,
        type,
        timestamp: new Date().toISOString(),
      }),
    });
  } catch {
    // fire-and-forget — never throw
  }
}
