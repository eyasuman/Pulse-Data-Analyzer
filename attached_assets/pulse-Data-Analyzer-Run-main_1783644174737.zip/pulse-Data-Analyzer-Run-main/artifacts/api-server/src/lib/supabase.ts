const SUPABASE_URL = "https://qxdqubzymuqgppwlzbsc.supabase.co";
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY!;

if (!SUPABASE_KEY) throw new Error("SUPABASE_SERVICE_KEY is not set");

const HEADERS = {
  "apikey": SUPABASE_KEY,
  "Authorization": `Bearer ${SUPABASE_KEY}`,
  "Content-Type": "application/json",
  "Prefer": "return=representation",
};

export async function sbSelect(table: string, qs = ""): Promise<any[]> {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}${qs}`, { headers: HEADERS });
  if (!r.ok) throw new Error(`Supabase GET ${table} failed: ${await r.text()}`);
  return r.json();
}

export async function sbInsert(table: string, body: object): Promise<any> {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
    method: "POST", headers: HEADERS, body: JSON.stringify(body),
  });
  const text = await r.text();
  if (!r.ok) throw new Error(`Supabase INSERT ${table} failed: ${text}`);
  const rows = JSON.parse(text);
  return Array.isArray(rows) ? rows[0] : rows;
}

export async function sbUpdate(table: string, filter: string, body: object): Promise<any> {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${filter}`, {
    method: "PATCH", headers: HEADERS, body: JSON.stringify(body),
  });
  const text = await r.text();
  if (!r.ok) throw new Error(`Supabase PATCH ${table} failed: ${text}`);
  const rows = JSON.parse(text);
  return Array.isArray(rows) ? rows[0] : rows;
}

export async function sbDelete(table: string, filter: string): Promise<any> {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${filter}`, {
    method: "DELETE", headers: HEADERS,
  });
  if (!r.ok) throw new Error(`Supabase DELETE ${table} failed: ${await r.text()}`);
  return { success: true };
}
