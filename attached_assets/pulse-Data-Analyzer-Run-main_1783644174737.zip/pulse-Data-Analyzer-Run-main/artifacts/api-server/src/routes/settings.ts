import { Router } from "express";
import { sbSelect, sbUpdate } from "../lib/supabase";
import { writeAudit } from "../lib/audit";

const router = Router();

router.get("/settings", async (req, res) => {
  try {
    const rows = await sbSelect("settings", "?id=eq.singleton");
    if (rows.length === 0) {
      // Return defaults if singleton row doesn't exist yet
      return res.json({
        platformFee: 10,
        cancellationNoticePeriodHours: 24,
        cancellationPenaltyFee: 50,
        reminderCadence: "daily",
        gatewayPassword: "0000",
        inactivityTimeoutMinutes: 5,
      });
    }
    res.json(normalizeSettings(rows[0]));
  } catch (err) {
    req.log.error({ err }, "GET /settings failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.put("/settings", async (req, res) => {
  try {
    const { platformFee, cancellationNoticePeriodHours, cancellationPenaltyFee, reminderCadence, gatewayPassword, inactivityTimeoutMinutes } = req.body;
    const updated = await sbUpdate("settings", "id=eq.singleton", {
      fixedPlatformFee: platformFee,
      noticePeriodHours: cancellationNoticePeriodHours,
      penaltyFee: cancellationPenaltyFee,
      reminderCadence,
      ...(gatewayPassword !== undefined ? { gatewayPassword } : {}),
      ...(inactivityTimeoutMinutes !== undefined ? { inactivityTimeoutMinutes } : {}),
      updatedAt: new Date().toISOString(),
      updatedBy: "admin",
    });
    await writeAudit("updated platform settings", "settings");
    res.json(normalizeSettings(updated));
  } catch (err) {
    req.log.error({ err }, "PUT /settings failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/settings/gateway-password", async (req, res) => {
  try {
    const { password } = req.body as { password: string };
    if (!password || password.length < 1) return res.status(400).json({ error: "Password required" });
    await sbUpdate("settings", "id=eq.singleton", { gatewayPassword: password, updatedAt: new Date().toISOString() });
    await writeAudit("changed gateway password", "settings");
    res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "PATCH /settings/gateway-password failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

function normalizeSettings(row: any) {
  return {
    platformFee: parseFloat(row.fixedPlatformFee) || 10,
    cancellationNoticePeriodHours: row.noticePeriodHours ?? 24,
    cancellationPenaltyFee: parseFloat(row.penaltyFee) || 50,
    reminderCadence: row.reminderCadence ?? "daily",
    gatewayPassword: row.gatewayPassword ?? "0000",
    inactivityTimeoutMinutes: row.inactivityTimeoutMinutes ?? 5,
  };
}

export default router;
