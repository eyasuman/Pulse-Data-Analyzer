import { Router } from "express";
import { sbSelect } from "../lib/supabase";

const router = Router();

router.get("/revenue", async (req, res) => {
  try {
    const rows = await sbSelect("revenue", "?order=id.asc");
    res.json(rows.map((r: any) => ({
      id: r.id,
      month: r.month ?? "",
      revenue: parseFloat(r.revenue) || 0,
      appointments: r.appointments ?? 0,
    })));
  } catch (err) {
    req.log.error({ err }, "GET /revenue failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
