import { Router } from "express";
import { sbSelect } from "../lib/supabase";

const router = Router();

router.get("/appointments", async (req, res) => {
  try {
    const rows = await sbSelect("appointments", "?order=date.desc");
    res.json(rows.map(normalizeAppointment));
  } catch (err) {
    req.log.error({ err }, "GET /appointments failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

function normalizeAppointment(row: any) {
  return {
    id: row.id,
    doctorName: row.doctorName ?? "",
    patientName: row.patientName ?? "",
    specialty: row.specialty ?? "",
    status: row.status ?? "pending",
    consultationFee: parseFloat(row.consultationFee) || 0,
    platformFee: parseFloat(row.platformFee) || 0,
    totalPrice: parseFloat(row.totalPrice) || 0,
    date: row.date ?? new Date().toISOString(),
    serviceType: row.serviceType ?? "",
    createdAt: row.createdAt ?? new Date().toISOString(),
  };
}

export default router;
