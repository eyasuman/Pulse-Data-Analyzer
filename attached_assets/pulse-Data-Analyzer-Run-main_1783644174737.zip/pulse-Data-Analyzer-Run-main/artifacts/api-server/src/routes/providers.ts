import { Router } from "express";
import { sbSelect, sbUpdate, sbInsert } from "../lib/supabase";
import { writeAudit } from "../lib/audit";

const router = Router();

router.get("/providers", async (req, res) => {
  try {
    const rows = await sbSelect("doctors", "?order=createdAt.asc");
    res.json(rows.map(normalizeProvider));
  } catch (err) {
    req.log.error({ err }, "GET /providers failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/providers/:id/status", async (req, res) => {
  const { id } = req.params;
  const { status } = req.body as { status: string };
  const valid = ["Active", "Pending", "Disabled", "Declined"];
  if (!valid.includes(status)) return res.status(400).json({ error: "Invalid status" });
  try {
    const [current] = await sbSelect("doctors", `?id=eq.${id}`);
    if (!current) return res.status(404).json({ error: "Not found" });
    const updated = await sbUpdate("doctors", `id=eq.${id}`, { status });
    await writeAudit(`updated provider "${current.name}" status from ${current.status} to ${status}`, "provider");
    res.json(normalizeProvider(updated));
  } catch (err) {
    req.log.error({ err }, "PATCH /providers/:id/status failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/providers", async (req, res) => {
  try {
    const created = await sbInsert("doctors", { ...req.body });
    await writeAudit(`created new provider "${created.name}" (${created.specialty})`, "provider");
    res.status(201).json(normalizeProvider(created));
  } catch (err) {
    req.log.error({ err }, "POST /providers failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

function normalizeProvider(row: any) {
  return {
    id: row.id,
    name: row.name,
    specialty: row.specialty,
    category: row.providerType?.toLowerCase() ?? "doctor",
    status: row.status ?? "Pending",
    email: row.email ?? "",
    phone: row.phone ?? "",
    city: row.city ?? "",
    consultationFee: parseFloat(row.consultationFee) || 0,
    experienceYears: row.experienceYears ?? 0,
    licenseNo: row.licenseNo ?? "",
    bio: row.bio ?? "",
    serviceModes: typeof row.serviceModes === "string" ? JSON.parse(row.serviceModes) : (row.serviceModes ?? { video: false, audio: false, inPerson: true, homeVisit: false }),
    createdAt: row.createdAt ?? new Date().toISOString(),
  };
}

export default router;
