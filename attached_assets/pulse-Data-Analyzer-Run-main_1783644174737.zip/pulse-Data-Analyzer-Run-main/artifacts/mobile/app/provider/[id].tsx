import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import { useData, DoctorStatus } from "@/context/DataContext";
import { StatusBadge } from "@/components/StatusBadge";

export default function ProviderDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { doctors, updateDoctorStatus } = useData();
  const [isUpdating, setIsUpdating] = useState(false);

  const doctor = doctors.find((d) => d.id === id);

  if (!doctor) {
    return (
      <View style={[styles.notFound, { backgroundColor: colors.background }]}>
        <Feather name="alert-circle" size={40} color={colors.mutedForeground} />
        <Text style={[styles.notFoundText, { color: colors.mutedForeground }]}>Provider not found</Text>
        <Pressable onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.primary }]}>
          <Text style={styles.backBtnText}>Go Back</Text>
        </Pressable>
      </View>
    );
  }

  const handleStatusChange = (newStatus: DoctorStatus) => {
    Alert.alert(
      `${newStatus} Provider`,
      `Are you sure you want to set ${doctor.name} to ${newStatus}?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Confirm",
          style: newStatus === "Declined" || newStatus === "Disabled" ? "destructive" : "default",
          onPress: async () => {
            setIsUpdating(true);
            await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            await updateDoctorStatus(doctor.id, newStatus);
            setIsUpdating(false);
            Alert.alert("Updated", `Provider status set to ${newStatus}.`);
          },
        },
      ]
    );
  };

  const topPt = Platform.OS === "web" ? 67 + 16 : insets.top + 16;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topPt, paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 30) },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.navRow}>
        <Pressable
          onPress={() => router.back()}
          style={[styles.backButton, { backgroundColor: colors.card, borderColor: colors.border }]}
        >
          <Feather name="arrow-left" size={16} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.navTitle, { color: colors.mutedForeground }]}>PROVIDER DETAIL</Text>
        <View style={{ width: 38 }} />
      </View>

      <View style={[styles.profileCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.profileTop}>
          <View style={[styles.avatar, { backgroundColor: colors.primary + "20", borderColor: colors.primary + "30" }]}>
            <Text style={[styles.avatarText, { color: colors.primary }]}>
              {doctor.name.split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase()}
            </Text>
          </View>
          <View style={styles.profileInfo}>
            <StatusBadge status={doctor.status} size="md" />
            <Text style={[styles.name, { color: colors.foreground }]}>{doctor.name}</Text>
            <Text style={[styles.specialty, { color: colors.mutedForeground }]}>
              {doctor.specialty} · {doctor.providerType}
            </Text>
          </View>
        </View>

        <View style={[styles.divider, { backgroundColor: colors.border }]} />

        <View style={styles.detailGrid}>
          <DetailItem icon="mail" label="Email" value={doctor.email} colors={colors} />
          {doctor.phone && <DetailItem icon="phone" label="Phone" value={doctor.phone} colors={colors} />}
          {doctor.city && <DetailItem icon="map-pin" label="City" value={doctor.city} colors={colors} />}
          <DetailItem icon="file-text" label="License" value={doctor.licenseNo} colors={colors} />
          {doctor.experienceYears !== undefined && (
            <DetailItem icon="award" label="Experience" value={`${doctor.experienceYears} years`} colors={colors} />
          )}
          <DetailItem icon="dollar-sign" label="Consultation Fee" value={`AED ${doctor.consultationFee}`} colors={colors} />
        </View>

        {doctor.bio ? (
          <>
            <View style={[styles.divider, { backgroundColor: colors.border }]} />
            <View>
              <Text style={[styles.bioLabel, { color: colors.mutedForeground }]}>BIO</Text>
              <Text style={[styles.bio, { color: colors.foreground }]}>{doctor.bio}</Text>
            </View>
          </>
        ) : null}
      </View>

      <View style={[styles.modesCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Service Modes</Text>
        <View style={styles.modesGrid}>
          <ModeItem label="Video" active={doctor.serviceModes.video} icon="video" colors={colors} />
          <ModeItem label="Audio" active={doctor.serviceModes.audio} icon="phone" colors={colors} />
          <ModeItem label="In-Person" active={doctor.serviceModes.inPerson} icon="user" colors={colors} />
          <ModeItem label="Home Visit" active={doctor.serviceModes.homeVisit} icon="home" colors={colors} />
        </View>
      </View>

      <View style={[styles.actionsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Admin Actions</Text>
        <View style={styles.actionsGrid}>
          {doctor.status !== "Active" && (
            <ActionButton
              label="Activate"
              onPress={() => handleStatusChange("Active")}
              color="#10b981"
              icon="check-circle"
              disabled={isUpdating}
            />
          )}
          {doctor.status !== "Pending" && (
            <ActionButton
              label="Set Pending"
              onPress={() => handleStatusChange("Pending")}
              color="#f59e0b"
              icon="clock"
              disabled={isUpdating}
            />
          )}
          {doctor.status !== "Disabled" && (
            <ActionButton
              label="Disable"
              onPress={() => handleStatusChange("Disabled")}
              color="#94a3b8"
              icon="slash"
              disabled={isUpdating}
            />
          )}
          {doctor.status !== "Declined" && (
            <ActionButton
              label="Decline"
              onPress={() => handleStatusChange("Declined")}
              color="#ef4444"
              icon="x-circle"
              disabled={isUpdating}
            />
          )}
        </View>
      </View>

      <View style={[styles.metaCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.metaItem, { color: colors.mutedForeground }]}>
          Registered: {new Date(doctor.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
        </Text>
        <Text style={[styles.metaItem, { color: colors.mutedForeground }]}>ID: {doctor.id}</Text>
      </View>
    </ScrollView>
  );
}

function DetailItem({ icon, label, value, colors }: { icon: any; label: string; value: string; colors: any }) {
  return (
    <View style={detailStyles.item}>
      <View style={[detailStyles.iconWrap, { backgroundColor: colors.muted, borderColor: colors.border }]}>
        <Feather name={icon} size={12} color={colors.mutedForeground} />
      </View>
      <View style={detailStyles.textWrap}>
        <Text style={[detailStyles.label, { color: colors.mutedForeground }]}>{label}</Text>
        <Text style={[detailStyles.value, { color: colors.foreground }]} numberOfLines={1}>{value}</Text>
      </View>
    </View>
  );
}

function ModeItem({ label, active, icon, colors }: { label: string; active: boolean; icon: any; colors: any }) {
  return (
    <View
      style={[
        modeStyles.item,
        {
          backgroundColor: active ? colors.primary + "12" : colors.muted,
          borderColor: active ? colors.primary + "30" : colors.border,
        },
      ]}
    >
      <Feather name={icon} size={14} color={active ? colors.primary : colors.mutedForeground} />
      <Text style={[modeStyles.label, { color: active ? colors.primary : colors.mutedForeground }]}>
        {label}
      </Text>
      {active && (
        <View style={[modeStyles.dot, { backgroundColor: colors.primary }]} />
      )}
    </View>
  );
}

function ActionButton({ label, onPress, color, icon, disabled }: any) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        actionStyles.btn,
        { backgroundColor: color + "14", borderColor: color + "30" },
        pressed && { opacity: 0.75 },
        disabled && { opacity: 0.5 },
      ]}
    >
      <Feather name={icon} size={14} color={color} />
      <Text style={[actionStyles.label, { color }]}>{label}</Text>
    </Pressable>
  );
}

const detailStyles = StyleSheet.create({
  item: { flexDirection: "row", alignItems: "center", gap: 10 },
  iconWrap: {
    width: 30,
    height: 30,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  textWrap: { flex: 1 },
  label: { fontSize: 9, fontFamily: "Inter_400Regular", letterSpacing: 0.5, textTransform: "uppercase" },
  value: { fontSize: 13, fontFamily: "Inter_500Medium", marginTop: 1 },
});

const modeStyles = StyleSheet.create({
  item: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    borderRadius: 10,
    borderWidth: 1,
    padding: 10,
  },
  label: { fontSize: 11, fontFamily: "Inter_500Medium", flex: 1 },
  dot: { width: 5, height: 5, borderRadius: 3 },
});

const actionStyles = StyleSheet.create({
  btn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    borderRadius: 12,
    borderWidth: 1,
    paddingVertical: 12,
  },
  label: { fontSize: 12, fontWeight: "600", fontFamily: "Inter_600SemiBold" },
});

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 16, gap: 14 },
  notFound: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  notFoundText: { fontSize: 16, fontFamily: "Inter_400Regular" },
  backBtn: { paddingHorizontal: 20, paddingVertical: 10, borderRadius: 10 },
  backBtnText: { color: "#fff", fontSize: 14, fontFamily: "Inter_600SemiBold" },
  navRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  backButton: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  navTitle: {
    fontSize: 9,
    fontWeight: "700",
    fontFamily: "Inter_700Bold",
    letterSpacing: 2,
  },
  profileCard: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 16,
    gap: 14,
  },
  profileTop: { flexDirection: "row", gap: 14, alignItems: "flex-start" },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: { fontSize: 18, fontWeight: "700", fontFamily: "Inter_700Bold" },
  profileInfo: { flex: 1, gap: 4 },
  name: { fontSize: 18, fontWeight: "700", fontFamily: "Inter_700Bold", letterSpacing: -0.3 },
  specialty: { fontSize: 12, fontFamily: "Inter_400Regular" },
  divider: { height: 1 },
  detailGrid: { gap: 10 },
  bioLabel: {
    fontSize: 9,
    fontWeight: "700",
    fontFamily: "Inter_700Bold",
    letterSpacing: 1.5,
    textTransform: "uppercase",
    marginBottom: 6,
  },
  bio: { fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 20 },
  modesCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    gap: 12,
  },
  modesGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  sectionTitle: {
    fontSize: 12,
    fontWeight: "600",
    fontFamily: "Inter_600SemiBold",
    letterSpacing: 0.3,
  },
  actionsCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    gap: 12,
  },
  actionsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  metaCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    gap: 6,
  },
  metaItem: { fontSize: 10, fontFamily: "Inter_400Regular", letterSpacing: 0.2 },
});
