import React, { useState, useEffect, useRef } from "react";
import {
  View, Text, StyleSheet, Pressable, Animated, Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";

interface Props {
  onUnlock: () => void;
  correctPassword: string;
}

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫"];
const PIN_LENGTH = 4;

export default function GatewayScreen({ onUnlock, correctPassword }: Props) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [entered, setEntered] = useState("");
  const [error, setError] = useState(false);
  const shakeAnim = useRef(new Animated.Value(0)).current;
  const fadeIn = useRef(new Animated.Value(0)).current;

  const isPinMode = correctPassword.length === 4 && /^\d{4}$/.test(correctPassword);

  useEffect(() => {
    Animated.timing(fadeIn, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (!isPinMode) return;
    if (entered.length === PIN_LENGTH) {
      if (entered === correctPassword) {
        onUnlock();
      } else {
        triggerError();
      }
    }
  }, [entered]);

  const triggerError = () => {
    setError(true);
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 8, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 60, useNativeDriver: true }),
    ]).start(() => {
      setEntered("");
      setError(false);
    });
  };

  const handleKey = (key: string) => {
    if (key === "⌫") {
      setEntered((p) => p.slice(0, -1));
    } else if (key === "") {
      // no-op
    } else {
      if (isPinMode && entered.length >= PIN_LENGTH) return;
      setEntered((p) => p + key);
    }
  };

  const handlePinSubmit = () => {
    if (!isPinMode) {
      if (entered === correctPassword) {
        onUnlock();
      } else {
        triggerError();
      }
    }
  };

  return (
    <Animated.View style={[styles.root, { backgroundColor: colors.background, opacity: fadeIn }]}>
      <View style={[styles.inner, { paddingTop: insets.top + 60, paddingBottom: insets.bottom + 24 }]}>
        {/* Logo / Brand */}
        <View style={styles.brand}>
          <View style={[styles.logoRing, { borderColor: colors.primary + "40" }]}>
            <View style={[styles.logoInner, { backgroundColor: colors.primary + "20" }]}>
              <Feather name="shield" size={28} color={colors.primary} />
            </View>
          </View>
          <Text style={[styles.appName, { color: colors.foreground }]}>PULSE NETWORK</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Admin Console</Text>
        </View>

        {/* Prompt */}
        <Text style={[styles.prompt, { color: colors.mutedForeground }]}>
          {isPinMode ? "Enter your 4-digit PIN" : "Enter gateway password"}
        </Text>

        {/* PIN dots or text */}
        {isPinMode ? (
          <Animated.View style={[styles.dotsRow, { transform: [{ translateX: shakeAnim }] }]}>
            {Array.from({ length: PIN_LENGTH }).map((_, i) => (
              <View
                key={i}
                style={[
                  styles.dot,
                  {
                    backgroundColor: i < entered.length
                      ? (error ? "#ef4444" : colors.primary)
                      : "transparent",
                    borderColor: error ? "#ef4444" : i < entered.length ? colors.primary : colors.border,
                  },
                ]}
              />
            ))}
          </Animated.View>
        ) : (
          <Animated.View style={[styles.textInputRow, { transform: [{ translateX: shakeAnim }] }]}>
            <View style={[styles.textBox, { backgroundColor: colors.card, borderColor: error ? "#ef4444" : colors.border }]}>
              <Text style={[styles.textValue, { color: colors.foreground }]}>
                {"•".repeat(entered.length)}
              </Text>
            </View>
          </Animated.View>
        )}

        {error && (
          <Text style={styles.errorText}>Incorrect password. Try again.</Text>
        )}

        {/* Keypad */}
        <View style={styles.keypad}>
          {KEYS.map((key, i) => {
            const isBlank = key === "";
            const isBack = key === "⌫";
            return (
              <Pressable
                key={i}
                style={({ pressed }) => [
                  styles.key,
                  {
                    backgroundColor: isBlank ? "transparent" : pressed ? colors.muted : colors.card,
                    borderColor: isBlank ? "transparent" : colors.border,
                    opacity: isBlank ? 0 : 1,
                  },
                ]}
                onPress={() => handleKey(key)}
                disabled={isBlank}
              >
                {isBack ? (
                  <Feather name="delete" size={20} color={colors.mutedForeground} />
                ) : (
                  <Text style={[styles.keyText, { color: colors.foreground }]}>{key}</Text>
                )}
              </Pressable>
            );
          })}
        </View>

        {/* Submit for non-pin passwords */}
        {!isPinMode && (
          <Pressable
            onPress={handlePinSubmit}
            style={[styles.submitBtn, { backgroundColor: colors.primary }]}
          >
            <Text style={styles.submitText}>Unlock</Text>
          </Pressable>
        )}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, zIndex: 9999 },
  inner: { flex: 1, alignItems: "center", justifyContent: "space-between", paddingHorizontal: 32 },
  brand: { alignItems: "center", gap: 8 },
  logoRing: { width: 80, height: 80, borderRadius: 40, borderWidth: 2, alignItems: "center", justifyContent: "center" },
  logoInner: { width: 60, height: 60, borderRadius: 30, alignItems: "center", justifyContent: "center" },
  appName: { fontSize: 18, fontWeight: "800", letterSpacing: 4, marginTop: 4 },
  subtitle: { fontSize: 12, letterSpacing: 1 },
  prompt: { fontSize: 13, letterSpacing: 0.5, marginTop: -16 },
  dotsRow: { flexDirection: "row", gap: 16, marginTop: -16 },
  dot: { width: 16, height: 16, borderRadius: 8, borderWidth: 2 },
  textInputRow: { width: "100%", marginTop: -16 },
  textBox: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 20, paddingVertical: 14, alignItems: "center" },
  textValue: { fontSize: 24, letterSpacing: 8 },
  errorText: { color: "#ef4444", fontSize: 12, marginTop: -24 },
  keypad: { width: "100%", flexDirection: "row", flexWrap: "wrap", gap: 12, justifyContent: "center" },
  key: {
    width: "28%",
    aspectRatio: Platform.OS === "web" ? undefined : 1,
    height: Platform.OS === "web" ? 60 : undefined,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Platform.OS === "web" ? 0 : 16,
  },
  keyText: { fontSize: 22, fontWeight: "500" },
  submitBtn: { width: "100%", borderRadius: 14, paddingVertical: 16, alignItems: "center" },
  submitText: { color: "#fff", fontSize: 15, fontWeight: "700" },
});
